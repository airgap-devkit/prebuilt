package Devel::StackTrace;
# =============================================================================
# Minimal pure-Perl Devel::StackTrace-compatible shim for offline lcov.
#
# lcov 2.5 (lcovutil.pm) loads Devel::StackTrace unconditionally but calls only
# `Devel::StackTrace->new->as_string`, and only when composing a verbose
# error/warning message. The real module is pure-Perl but not part of a base
# Perl and not on a stock RHEL/Rocky, so on an air-gapped host lcovutil failed to
# compile and genhtml could not run. This shim implements new()/as_string() (plus
# a frames() accessor) with core Perl caller() — enough for that diagnostic —
# without the real module's footprint. Constructor options are accepted/ignored.
# =============================================================================
use strict;
use warnings;

our $VERSION = '0.00_lcov_shim';

sub new {
    my ($class, %opts) = @_;
    my @frames;
    my $i = 1;   # skip this constructor frame
    while (my @c = caller($i++)) {
        push @frames, { subroutine => $c[3], filename => $c[1], line => $c[2] };
        last if @frames >= 100;   # defensive bound
    }
    return bless { frames => \@frames }, ref($class) || $class;
}

sub as_string {
    my $self = shift;
    my $out = '';
    for my $f (@{ $self->{frames} }) {
        $out .= "\t$f->{subroutine} called at $f->{filename} line $f->{line}\n";
    }
    return $out;
}

sub frames { return @{ $_[0]->{frames} }; }

1;
