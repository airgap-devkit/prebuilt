package DateTime;
# =============================================================================
# Minimal pure-Perl DateTime-compatible shim for offline lcov / genhtml.
#
# lcov 2.5 (genhtml, lcovutil) loads DateTime unconditionally but exercises only
# a narrow slice of its API:
#     DateTime->from_epoch(epoch => N)
#     DateTime->now()
#     DateTime->new(year => .., month => .., day => .., hour => .., ...)
#     $dt->delta_days($other)->in_units('days')     # whole-day age, >= 0
# It never formats these objects beyond that. This shim implements exactly that
# surface (plus a few defensive accessors and stringification) using only core
# Perl — no XS, no CPAN deps — so it behaves identically on glibc and musl and
# needs no per-platform build. It is deliberately NOT a general DateTime: times
# are treated as UTC, which is exact for the whole-day deltas lcov computes.
# =============================================================================
use strict;
use warnings;
use Time::Local ();
use overload '""' => \&iso8601, 'fallback' => 1;

our $VERSION = '0.00_lcov_shim';

sub from_epoch {
    my ($class, %arg) = @_;
    my $e = $arg{epoch};
    die "DateTime::from_epoch: undefined epoch\n" unless defined $e;
    return bless { epoch => int($e) }, ref($class) || $class;
}

sub now {
    my $class = shift;
    return bless { epoch => time() }, ref($class) || $class;
}

sub new {
    my ($class, %arg) = @_;
    die "DateTime::new: 'year' is required\n" unless defined $arg{year};
    my $mon = defined $arg{month}  ? $arg{month}  : 1;
    my $day = defined $arg{day}    ? $arg{day}    : 1;
    my $h   = defined $arg{hour}   ? $arg{hour}   : 0;
    my $min = defined $arg{minute} ? $arg{minute} : 0;
    my $s   = defined $arg{second} ? $arg{second} : 0;
    # time_zone is accepted for call compatibility but not honored: lcov uses
    # these objects only for whole-day deltas, where a common zone cancels out.
    my $epoch = Time::Local::timegm($s, $min, $h, $day, $mon - 1, $arg{year});
    return bless { epoch => $epoch }, ref($class) || $class;
}

sub epoch { $_[0]->{epoch} }

# Whole-day difference, always non-negative — matches DateTime->delta_days,
# which returns an absolute DateTime::Duration.
sub delta_days {
    my ($self, $other) = @_;
    my $days = int(abs($other->{epoch} - $self->{epoch}) / 86400);
    return DateTime::Duration->_new_days($days);
}

sub year   { (gmtime($_[0]->{epoch}))[5] + 1900 }
sub month  { (gmtime($_[0]->{epoch}))[4] + 1 }
sub day    { (gmtime($_[0]->{epoch}))[3] }
sub hour   { (gmtime($_[0]->{epoch}))[2] }
sub minute { (gmtime($_[0]->{epoch}))[1] }
sub second { (gmtime($_[0]->{epoch}))[0] }

sub ymd {
    my ($self, $sep) = @_;
    $sep = '-' unless defined $sep;
    return sprintf('%04d%s%02d%s%02d', $self->year, $sep, $self->month, $sep, $self->day);
}

sub hms {
    my ($self, $sep) = @_;
    $sep = ':' unless defined $sep;
    return sprintf('%02d%s%02d%s%02d', $self->hour, $sep, $self->minute, $sep, $self->second);
}

sub datetime { my $s = shift; return $s->ymd('-') . 'T' . $s->hms(':'); }
sub iso8601  { my $s = shift; return $s->datetime . 'Z'; }
sub set_time_zone { return $_[0]; }   # no-op: this shim is UTC-only

package DateTime::Duration;

sub _new_days { return bless { days => $_[1] }, $_[0]; }

sub in_units {
    my ($self, $unit) = @_;
    return $self->{days} if !defined($unit) || $unit eq 'days' || $unit eq 'day';
    return 0;
}

1;
