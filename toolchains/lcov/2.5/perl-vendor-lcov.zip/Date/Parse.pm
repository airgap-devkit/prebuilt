package Date::Parse;
# =============================================================================
# Minimal pure-Perl Date::Parse::str2time shim for offline lcov / genhtml.
#
# lcov 2.5 calls only Date::Parse::str2time($string) and expects an epoch, or
# undef on failure (which lcov handles by falling back to a file's mtime, inside
# an eval). This shim parses the formats lcov realistically feeds — ISO-8601 /
# W3CDTF, "YYYY-MM-DD[ T]HH:MM[:SS] [±ZZ[:]ZZ|Z]", and a bare epoch — using only
# core Perl (Time::Local). It is intentionally narrower than CPAN Date::Parse:
# unrecognized input returns undef, which triggers lcov's own mtime fallback.
# =============================================================================
use strict;
use warnings;
use Time::Local ();
use Exporter ();

our @ISA       = qw(Exporter);
our @EXPORT    = qw(str2time);
our @EXPORT_OK = qw(str2time strptime);
our $VERSION   = '0.00_lcov_shim';

sub str2time {
    my ($str) = @_;
    return undef unless defined $str;
    $str =~ s/^\s+//;
    $str =~ s/\s+$//;
    return undef if $str eq '';

    # A bare epoch (10-digit-ish integer) passes straight through.
    return int($str) if $str =~ /^\d{9,}$/;

    my ($y, $mo, $d, $h, $mi, $s, $tz);
    if ($str =~ m{
            ^(\d{4})-(\d{2})-(\d{2})            # YYYY-MM-DD
            (?:[T ](\d{2}):(\d{2})(?::(\d{2}))? # optional  HH:MM[:SS]
            (?:\.\d+)?)?                        # optional fractional seconds
            \s*(Z|[+-]\d{2}:?\d{2})?            # optional TZ (Z or ±HH[:]MM)
        }x
    ) {
        ($y, $mo, $d, $h, $mi, $s, $tz) = ($1, $2, $3, $4, $5, $6, $7);
    } else {
        return undef;
    }
    $h  = 0 unless defined $h;
    $mi = 0 unless defined $mi;
    $s  = 0 unless defined $s;

    my $epoch = eval { Time::Local::timegm($s, $mi, $h, $d, $mo - 1, $y) };
    return undef unless defined $epoch;

    # The parsed fields are wall-clock at $tz; convert to true UTC. timegm gave
    # us the epoch as if the fields were UTC, so subtract the zone offset.
    if (defined $tz && $tz ne 'Z') {
        if (my ($sign, $oh, $om) = $tz =~ /^([+-])(\d{2}):?(\d{2})$/) {
            my $off = ($oh * 3600 + $om * 60) * ($sign eq '-' ? -1 : 1);
            $epoch -= $off;
        }
    }
    return $epoch;
}

# Not used by lcov; present so `use Date::Parse qw(strptime)` won't fail.
sub strptime { return undef; }

1;
